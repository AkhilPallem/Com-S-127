# Akhil            11-25-22
# Assignment #6 Naval Battle

import gameBoard
import gamePlay

def main():
    """This is the main function of the game. It controls the flow/ execution of the entire script.
    """
    gameOver = False

    gameboardChoice = 0
    humanGameBoard = None
    targetBoard = None
    computerGameBoard = None
    
    numHumanTargets = 0
    numComputerTargets = 0
    
    print("Welcome to Naval Battle!")
    print()
    
    print("By: Akhil Pallem")
    print("[COM S 127 A]")
    print()

    while gameOver == False:
        choice = input("[p]lay, [i]nstructions, or [q]uit?: ")
        print()
        if choice == "p": 
            gameboardChoice = gameBoard.chooseHumanGameBoard()

            humanGameBoard, numHumanTargets = gameBoard.loadGameBoard(gameboardChoice)

            gameboardChoice = gameBoard.chooseComputerGameBoard()

            computerGameBoard, numComputerTargets = gameBoard.loadGameBoard(gameboardChoice)

            targetBoard = gameBoard.loadTargetBoard()

            gamePlay.runGame(humanGameBoard, targetBoard, computerGameBoard, numHumanTargets, numComputerTargets)
        elif choice == "i":
            print("Take turns with the computer trying to guess where each ships are!")
            print("Sink all of your opponents ships and you win!")
        elif choice == "q":
            print("Goodbye...")
            gameOver = True 
        else:
            print()
            print("Please enter [p], [i], or [q]...")
            print()

if __name__ == "__main__":
    main()